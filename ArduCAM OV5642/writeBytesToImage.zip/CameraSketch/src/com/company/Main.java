package com.company;

import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Arrays;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) throws IOException {
        String data = null;
        try {
            // loading Image data file
            File myObj = new File("jpegArray.txt");
            Scanner myReader = new Scanner(myObj);

            while (myReader.hasNextLine()) {
                data = myReader.nextLine();
            }
            myReader.close();

        } catch (FileNotFoundException e) {
            System.out.println("An error occurred.");
            e.printStackTrace();
        }

        assert data != null;
        String[] jpegArray = data.split(",");

        // converting the string array to int array
        int[] intArray = Arrays.stream(jpegArray).mapToInt(Integer::parseInt).toArray();

        int x = intArray.length;
        byte[] byteArray = new byte[x];

        // converting the int array to byte array
        for (int i=0; i < x; i++) {
            byteArray[i] = (byte) intArray[i];
        }

        ByteArrayInputStream bis = new ByteArrayInputStream(byteArray);

        //Writing byte array to an Image
        BufferedImage bImage2 = ImageIO.read(bis);
        ImageIO.write(bImage2, "jpg", new File("output.jpg") );
        
        System.out.println("image created!");
    }

}
